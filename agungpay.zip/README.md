# Agung PAY(Aplikasi Pembayaran Listrik Pasca Bayar)
Sebuah aplikasi berbasis web yang bertujuan untuk membayar listrik pasca bayar

## Fitur
* Dashboard
![Foto Dashboard](ss_program/dashboard.png "Dashboard Agen")

* Daftar Penggunaan Listrik
![Foto Daftar Penggunaan Listrik ](ss_program/daftar_penggunaan.png "Daftar Penggunaan Listrik")

* Riwayat Pembayaran Listrik
![Foto Riwayat Pembyaran Listrik](ss_program/riwayat_transaksi.png "Riwayat Pembayaran Listrik")

## Teknologi
* PHP 5
* MySQL
* HTML
* CSS
* Javascript
* Bootstrap 

## Credit Developer
* [Email](mailto:programzidun@gmail.com) - programzidun@gmail.com
* [LinkedIn](https://www.linkedin.com/in/ramdanzidun/) - Muhammad Ramdan

```
 Ku Coding Kau dengan Bismillah
```


