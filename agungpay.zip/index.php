<br> <br> <br> <br>  
<!DOCTYPE html>
<html>
<head>
	<title>AGUNG PAY</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="background-color: #eeeeee;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-body">
						<h3>Silahkan Pilih Menu Login</h3>

						<a href="http://127.0.0.1/agungpay/agen/index.php">
							<img src="images/logoagungpay.png" width="150px" >
						</a>

						<a href="http://127.0.0.1/agungpay/pln/index.php">
							<img src="images/logo_pln.png" width="150px" >
						</a>

					</div>
					<!-- footer -->
					<div class="panel-footer">
							<center>&copy;<?php echo date("Y"); ?> - AGUNG PRIHANDOKO</center>
						</div>
						<!-- end footer -->
				</div>
			</div>
		</div>
	</div>
</body>
</html>